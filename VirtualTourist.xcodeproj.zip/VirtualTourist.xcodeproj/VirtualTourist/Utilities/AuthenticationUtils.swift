//
//  AutheticationUtils.swift
//  VirtualTourist
//
//  Created by Darin Williams on 5/25/19.
//  Copyright © 2019 dwilliams. All rights reserved.
//

import Foundation

struct AuthenticationUtils {
  
    static let headerPost = "POST"
    static let headerGet = "GET"

    
}
